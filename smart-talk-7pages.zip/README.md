
# Smart Talk - 7 Pages

A simple multi-page static website for Smart Talk, built with HTML and CSS.

## Pages
- Home (index.html)
- About (about.html)
- Contact (contact.html)
- Login (login.html)
- Register (register.html)

## Live Site
[Visit Smart Talk Website](https://smart-talk-d5pf.onrender.com)
