
# Smart Talk - Multi-Page

A simple static website for Smart Talk with Home, About, and Contact pages.

## Pages
- Home: index.html
- About: about.html
- Contact: contact.html
